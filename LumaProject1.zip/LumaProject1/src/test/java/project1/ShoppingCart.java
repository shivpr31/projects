package project1;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class ShoppingCart {
	
WebDriver driver;
	
	public ShoppingCart(WebDriver idriver) 
	{
		driver=idriver;
		PageFactory.initElements(driver, this);
		
	}
	
	
	//Add to cart
	  @FindBy (xpath="//button[@id='product-addtocart-button']") WebElement addToCart;
	  
    //Show Cart
	  @FindBy (xpath="//a[@class='action showcart']")  WebElement showCart;
	  
	  
	  //counter no
	  @FindBy (xpath= "//div[@class='header content']/child::div[1]/child::a/descendant::span[3]") WebElement counternumber;
	  
	//5items= no of items
	 @FindBy (xpath="//div[@class='items-total']/span[1]") WebElement itemsinCart;
	  
	  //Check Cart subtotal
	  @FindBy (xpath= "//div[@class='subtotal']/descendant::span[4]") WebElement cartSubtotal;
	  
	  
	  //SeeDetails in Cart
	  @FindBy (xpath="//div[@class='product options']/descendant::span[2]") WebElement seeDetails;
	  
	  //View and Edit Cart
	  @FindBy  (xpath="//a[@class='action viewcart']/child::span") WebElement viewEditCart;
	  
	  //Change Quantity after cart added selection
	  @FindBy (xpath="//input[@class='input-text qty']") WebElement changeQuantity;
	  
	  //Update Shopping cart
	  @FindBy (xpath="//button[@class='action update']/child::span") WebElement updateShoppingCart;
	  
	  //Remove items
	  @FindBy (xpath="//a[@class='action action-delete']") WebElement itemsDeleted;
	  
	  //Cart Empty message 
	  @FindBy (xpath="//div[@class='cart-empty']/child::p[1]") WebElement emptyCartmessage;
	  
	  //add to compare
	  @FindBy (xpath="//div[@class='column main']/descendant::a[4]") WebElement addtocompare;
	  
	  //Comparison list message - click
	  @FindBy (xpath="//main[@id='maincontent']/child::div[1]/descendant::div[5]/child::a") WebElement compareList;
	  
	  //Remove compare product
	  @FindBy (xpath="//a[@class='action delete']") WebElement removeCompare;
	  
	  //OK item - compare
	  @FindBy (xpath="//button[@class='action-primary action-accept']") WebElement oK;
	  
	  //Add to WishList
	  @FindBy (xpath="//div[@class='column main']/child::div[3]/child::ol/child::li[5]/child::div/child::div/child::div[3]/descendant::div[3]/child::a[1]") WebElement addtoWishList;
	  
	  //Add All to cart
	  @FindBy (xpath="//button[@class='action tocart']") WebElement addAlltocart;
	  
	  //Gym Tank size = to add to cart
	  @FindBy (xpath="//div[@class='swatch-opt']/child::div[1]/child::div/child::div[2]") WebElement gymTankSize;
	  
	  //Gym Tank color - green = to add to cart
	  @FindBy (xpath="//div[@class='swatch-opt']/child::div[2]/child::div/child::div[1]") WebElement greenColor; 
	  
	  //Shoppig cart = checkout - shopping cart message
	  @FindBy (xpath="//main[@id='maincontent']/child::div[1]/descendant::div[5]/child::a") WebElement shoppingcartLink;
	  
	//Quantity of Gym tank
	  @FindBy (xpath="//input[@id='qty']") WebElement quantityGymTank;
	  
	  //Choices - new Gear - ADD TO CART
	  @FindBy (xpath="//div[@class='block crosssell']/child::div[2]/child::div/child::ol/child::li[1]/descendant::div[9]/descendant::button") WebElement cardioBall;
	
	
	  //==================================================================Checkout=================================================
	  //Proceed to checkout
	  @FindBy (xpath="//div[@class='column main']/child::div[2]/child::div[1]/child::ul/child::li[1]/child::button") WebElement checkout;
	 
	  //Multiple checkout address
	  @FindBy (xpath="//a[@class='action multicheckout']") WebElement multicheckout;
	  
	  
	  //Shipping details
	  //Street Address
	  @FindBy (xpath="//input[@name='street[0]']") WebElement streetname;
	  
	  //City name
	  @FindBy (xpath="//input[@name='city']") WebElement cityname;
	  
	  //Select state
	  @FindBy (name="region_id")  WebElement statename;
	  
	  
	//Post Code
	  @FindBy (xpath="//input[@name='postcode']") WebElement postcode;
	  
	  //Telephone
	  @FindBy (xpath="//input[@name='telephone']") WebElement telephone;
	  
	  //Shipping method -radio
	  @FindBy (xpath="//div[@id='checkout-shipping-method-load']/child::table/child::tbody/child::tr[1]/child::td[1]/child::input") WebElement shippingRadio;
	  
	  //NEXT- submit BTN
	  @FindBy (xpath="//button[@class='button action continue primary']") WebElement nextBTN;
	  
	  //'billing-address-same-as-shipping'
	  @FindBy (xpath="//input[@name='billing-address-same-as-shipping']") WebElement addressBillShipping;
	  
	  //Place Order
	  @FindBy (xpath="//div[@class='column main']/child::div[2]/child::div[4]/child::ol/child::li[3]/child::div/descendant::div[51]/child::button") WebElement placeorder;

	  
	  //Continue shopping order
	  @FindBy (xpath= "//a[@class='action primary continue']") WebElement continueToShop;
	  
	  //New Address for shipping
	  @FindBy (xpath="//div[@class='column main']/child::div[2]/child::div[4]/child::ol/child::li[1]/child::div[2]/child::div[2]/child::button")  WebElement newaddress;
	  
	  //Ship here  >> New Address
	  @FindBy (xpath="//button[@class='action primary action-save-address']")  WebElement shiphere;
	  
	  
	  
	  public void ClickAddtoCartButton() throws InterruptedException
	  {
   	   addToCart.click();
   	   Thread.sleep(2000);
      }
	  
	  public void ClickShowtoCartDropdown() throws InterruptedException 
	  {     if(counternumber.isDisplayed())
	  {   Thread.sleep(10000);
		  showCart.click();
		  System.out.println("The counter number of items in the cart is: " + counternumber);
		  
	  }
	      }
	 
	  public void  CartItems() {
		  System.out.println(itemsinCart.getText());
		  
	  }

       public void ValueofCartSubTotal() 
    {
    	String TotalPrice= cartSubtotal.getText();
    	System.out.println("The value of the price :" +TotalPrice);
    	
    }
      
      public void DetailsSee() throws InterruptedException {
    	  seeDetails.click();
    	  Thread.sleep(2000);
      }
      
      public void ClickViewEditCart() {
    	  viewEditCart.click();
      }
      
      public void EnterQuantitychange(String pm)
      {
    	  changeQuantity.clear();
    	  changeQuantity.sendKeys(pm);   //select 5
	   }
      public void ClickUpdateShopCart() throws InterruptedException {
    	  updateShoppingCart.click();
    	  Thread.sleep(2000);
      }
      public void ClickRemoveItems() {
    	  itemsDeleted.click();
      }
      public void EmptyCartMessage() {
    	  String message= emptyCartmessage.getText();  //Message: You have no items in your shopping cart
    	  System.out.println(message);
    	 
      }
      //============================================================Women==========================================================
      public void AddToCompare()
      {
    	  try {
  		addtocompare.click();
  	
  		
    	  }catch(Exception e)
    	  {
    		  System.out.println(e.getMessage());  //Invalid form key
    	  }
  		
  	}
      
     public void CompareList() {
    		compareList.click();
     }
     
     public void RemoveCompareProduct() throws InterruptedException {
    	 removeCompare.click();
    	 Thread.sleep(2000);
  }
     
     public void ClickOnOKitem() throws InterruptedException {
    	 oK.click();
    	 Thread.sleep(2000);
     }
     
     
     public void AddToWishList() throws InterruptedException
     {
   	  try {
   		addtoWishList.click();
   		Thread.sleep(2000);
 	
 		
   	  }catch(Exception e)
   	  {
   		  System.out.println(e.getMessage()); 
   	  }
 		
 	}
      
     public void AddALLtoCart()   //from wishlist
     {  
    	 try
    	 {
    	 addAlltocart.click();
    	 Thread.sleep(2000);
    	 
    	 } catch(Exception e) 
    	 { 
    		 System.out.println(e.getMessage());   //You need to choose options for your item for "Sparta Gym Tank".
    		 
    	 }
     }
     
     public void ClickGymTankSize() throws InterruptedException {
			JavascriptExecutor js= (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,500)");
	
		    gymTankSize.click();
		    
			
			}
     
     public void EnterGYMTankQuantity(String um)
     {
  	   quantityGymTank.clear();
  	   quantityGymTank.sendKeys(um);   //select 7
	   }
     
		
		public void ClickGymTankGreen() {
			
			greenColor.click();
			}
     
   
		
		public void ClickShoppingCartLink() throws InterruptedException       //You added Sparta Gym Tank to your shopping cart.
		{        
			shoppingcartLink.click();
			Thread.sleep(5000);
		}
     
		public void AddCartCardioBall() {
			try {
			cardioBall.click();
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
			
		}
		
		//===============================CHECKOUT================================================================================
		
		public void ProceedToCheckout() throws InterruptedException {
			JavascriptExecutor js= (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,500)");
	
			checkout.click();
			Thread.sleep(3000);
		}
		
		
		public void multipleCheckoutAddress() throws InterruptedException {
			multicheckout.click();
			Thread.sleep(2000);
		}
		
	
		
		//=================================================Shipping details /Review========================================
		
		
		 public void StreetAddress(String sa) {
			streetname.sendKeys(sa);
		}
		 
		 public void CityName(String cn) {
				cityname.sendKeys(cn);
			}
		 
		 public void StateName() 
		 {   try {
				 Select sc1 = new Select(statename);
				 sc1.selectByVisibleText("New York");  
		 } catch (Exception e )
		 {
			 System.out.println(e);
		 }
			}
		 
		 public void PostCode(String pc) {
			 postcode.sendKeys(pc);
			}
		 
		 public void EnterTelephone(String et) {
			 telephone.sendKeys(et);
			}
		 
		 public void ShippingMethodBTN() {
			 shippingRadio.click();
		 }
		 
		 public void SubmitBTN() {
			nextBTN.click();
		 }
		 
		 
		 
		 public void ClickonBillingsameShipping() {
			 try {
			 addressBillShipping.click();
			 Thread.sleep(2000);
			 }
			 catch (Exception e)
			 {
				 System.out.println(e);
			 }
		 }
		 
		 
		 //Message: Current Customer does not have an active cart (When the order is placed and user clicks on the "PLACE ORDER" again.
		 public void ClickPlaceOrderBTN() {
			 try {
			 placeorder.click();
			 Thread.sleep(2000);
			 }
			 catch (Exception e)
			 {
				 System.out.println(e);
			 }
			 
		 }
		 
		 //Order no: 000006430.>>> Verified
		 
		 public void CLickonContinueShopBTN() throws InterruptedException {
			 continueToShop.click();
			 Thread.sleep(2000);
		 }
		 
		 //New Address
		 public void ClickonNewAddressBTN() throws InterruptedException {
			 newaddress.click();
			 Thread.sleep(2000);
		 }
		 
		 //Ship here
		 public void ClickShipHereBTN() throws InterruptedException {
			 shiphere.click();
			 Thread.sleep(2000);
		 }
		 
		 
		 
}


