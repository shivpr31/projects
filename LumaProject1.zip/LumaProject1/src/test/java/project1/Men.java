package project1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class Men {
	
WebDriver driver;
	
	public Men(WebDriver idriver) 
	{
		driver=idriver;
		PageFactory.initElements(driver, this);
		
	}
	
	//Men
	@FindBy (xpath="//ul[@id='ui-id-2']/child::li[3]/descendant::span[2]") WebElement boy;
	
	//Men:  Tops / Tanks
	@FindBy (xpath="//nav[@class='navigation']/descendant::li[12]/child::a[1]") WebElement topmen;
	@FindBy (xpath="//nav[@class='navigation']/descendant::li[16]/child::a[1]") WebElement tanksmen;
	
	
	//Show No of page verify - dropdown
		@FindBy (id="limiter") WebElement showPage;
			
		//Men:  bottoms / pants
		@FindBy (xpath="//nav[@class='navigation']/descendant::li[17]/child::a[1]/child::span[1]") WebElement bottommen;
		@FindBy (xpath="//nav[@class='navigation']/descendant::li[18]/child::a[1]") WebElement pantsmen;
		
		@FindBy (xpath="//div[@class='column main']/child::div[3]/child::ol/child::li[5]/child::div/child::div/descendant::a[1]") WebElement spartaGymTank;
		

	
	public void TabMen() throws InterruptedException {
		Actions act= new Actions(driver);
		act.moveToElement(boy).build().perform();
		Thread.sleep(2000);
		
	}

	public void MensTops() {
		Actions act= new Actions(driver);
		act.moveToElement(topmen).build().perform();
		
	}
	
	public void TopsTanks() throws InterruptedException {
		Actions act= new Actions(driver);
		act.moveToElement(tanksmen).build().perform();
		tanksmen.click();
		Thread.sleep(2000);
		
		JavascriptExecutor js= (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,3500)");
		Thread.sleep(2000);
	}
		
	
    public void ShowPage() throws InterruptedException {
    	
    	try {
		Select sc = new Select(showPage);

	     sc.selectByVisibleText("36");
		Thread.sleep(1000);}
    	catch(Exception e)
    	{
    		System.out.println(e);
    	}
		
		JavascriptExecutor js= (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,-3500)");
		Thread.sleep(2000);
		
	}
	
    public void HoverSpartaGymTank() throws InterruptedException {
		Actions act= new Actions(driver);
		act.moveToElement(spartaGymTank).build().perform();
		Thread.sleep(2000);
		//spartaGymTank.click();
		//Thread.sleep(2000);
	}
	
    public void ClickSpartaGymTank() throws InterruptedException {
  		
  		//spartaGymTank.click();
  		//Thread.sleep(2000);
    	
    	List<WebElement> links= driver.findElements(By.tagName("a"));
		System.out.println("Total no of links for Sparta Gym Tank: "+ links.size());
		for(int z=0;z<links.size();z++) 
		{
			WebElement currentlink= links.get(z);
			String name=currentlink.getText();
			if(name.equalsIgnoreCase("Sparta Gym Tank")) 
			{
				currentlink.click();
				
				break;
			}
			
		
  	}
	
	
	
    }
	
	
}


