package project1;

import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class SearchEntireStoreHere {
	
	WebDriver driver;
	
	public SearchEntireStoreHere(WebDriver idriver)
    {
	driver=idriver;
	PageFactory.initElements(driver, this);
     }
	
	//Search
	@FindBy (id="search") WebElement searchfeature;
	@FindBy (xpath="//div[@class='footer content']/child::ul/child::li[3]/child::a") WebElement advanceSearch;
	@FindBy (id="sku") WebElement stockKeepingUnit;
	@FindBy (xpath="//div[@class='column main']/child::form/child::div/child::div/child::button/child::span") WebElement searchbutton;
	@FindBy (xpath="//div[@class='search found']/child::strong") WebElement searchfoundItem;
	
	@FindBy (xpath="//div[@id='search_autocomplete']/child::ul/child::li/child::span") List<WebElement> autoSearch;
	
	public void EnterSearch(String es) throws InterruptedException {

		
		if (searchfeature.isEnabled())
		{
		searchfeature.sendKeys(es);
		Thread.sleep(5000);
		}
		
	
		
	}

	
	public void AutoSearchList() {
		System.out.println("AutoSearch Size is " +autoSearch.size());
		for(int v=0; v<autoSearch.size();v++) {
			
			String autoNames = autoSearch.get(v).getText();
			
			
			if (autoNames.contains("pants") )  {
				System.out.println((v+".0  ") + "List of the search of - pant is  :" +autoNames);
			
				
			}
			
		}
	}
	
	
	public void AdvancedSearch() {
		
		JavascriptExecutor js= (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,3500)");
		
		advanceSearch.click();
		

		
	}
	
	public void EnterProductSKU(String sku) {
		stockKeepingUnit.sendKeys(sku);
	}
	
	public void ClickSearchBtn() throws InterruptedException {
		searchbutton.click();
		Thread.sleep(2000);
	}
	
	public void SearchitemFound() {
		if(searchfoundItem.isDisplayed()) {
			System.out.println("Search item value is  "+(searchfoundItem.getText())); 
			System.out.println("Test case is a PASS");
			
		}else
		{
			System.out.println("Test case is a FAIL");
		}
	}
	
	
	
	
	
	
	
}


