package project1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

public class WhatsNew 
{
	WebDriver driver;
	
	public WhatsNew(WebDriver idriver) 
	{
		driver=idriver;
		PageFactory.initElements(driver, this);
		
	}
	
	//What's new
	
	@FindBy (xpath="//nav[@class='navigation']/descendant::a[1]") WebElement whatsnew;
	
	//================================================================================================================================
	
	//Women-hoodies&sweat shirts
	@FindBy (xpath="//div[@class='categories-menu']/descendant::li[1]/child::a") WebElement hoodieswomen;
	
	//style
	@FindBy (xpath="//div[@id='narrow-by-list']/descendant::div[2]") WebElement style;
	
	//fullzip
	@FindBy (xpath="//div[@class='filter-options']/descendant::li[1]/child::a") WebElement fullzip;
	
	//Size
	@FindBy (xpath="//div[@class='filter-options']/descendant::div[2]") WebElement size;
	@FindBy (xpath="//div[@class='filter-options']/descendant::div[5]/child::a[4]/child::div[1]") WebElement L_size;
	
	//Selene Yoga Hoodie,hover
	@FindBy (xpath="//div[@class='column main']/descendant::li[6]") WebElement SeleneYogaHoodie_hover;
	
	//Clear All
	@FindBy (xpath="//a[@class='action clear filter-clear']") WebElement clearAll;
	
	//=============================================================================================================================
	
	//New in Women -pants
	 @FindBy (xpath="//div[@class='categories-menu']/descendant::li[5]/child::a") WebElement pants;
	 
	 //climate
	  @FindBy (xpath="//div[@id='narrow-by-list']/child::div[3]/child::div[1]") WebElement climate;
	     //warm
	  @FindBy (xpath="//div[@id='narrow-by-list']/child::div[3]/child::div[2]/child::ol/child::li[6]/child::a") WebElement warm;
	  
	  //Color
	  @FindBy (xpath="//div[@id='narrow-by-list']/child::div[4]/child::div[1]") WebElement color;
	  
	  //ColorMenuList = 9 colors
	  @FindBy (xpath= "//div[@class='swatch-option color ']")  WebElement colorMenu;   
	  
	    //Gray
	 // @FindBy (xpath="//div[@id='narrow-by-list']/child::div[4]/child::div[2]/descendant::a[3]/div") WebElement gray;
	  
	  //List view
	  @FindBy (xpath="//div[@class='column main']/child::div[2]/child::div[1]/child::a") WebElement list;
	  
	  //Size
	  @FindBy (xpath="//div[@class='swatch-opt']/child::div[1]/child::div/child::div[2]") WebElement dariaBikram_pant_size;
	  
	//Color 
	  @FindBy (xpath="//div[@class='swatch-opt']/child::div[2]/child::div/child::div[2]") WebElement dariaBikram_pant_color;
	  
	  
	  //More information
	  @FindBy (xpath="//a[@id='tab-label-additional-title']") WebElement moreinformation;
	  
	
	  
	  //Product details
	  @FindBy (xpath="//a[@id='tab-label-description-title']") WebElement productdetails;
	  
	  //Reviews
	  @FindBy (xpath="//a[@id='tab-label-reviews-title']") WebElement reviews;
	  
	  
	     //Ratings
	  @FindBy (id="Rating_1_label") WebElement ratings;
	  
	  	//Nickname
	  @FindBy (id="nickname_field") WebElement nickname;
	  
	  //Summary field
	  @FindBy (id="summary_field") WebElement summaryfield;
	  
	  //Nickname
	  @FindBy (id="review_field") WebElement reviewfield;
	  
	  
	  //Submit review
	  @FindBy  (xpath="//button[@class='action submit primary']") WebElement submitreview;
	  
	  //==========================================================================================================================
	  
	 
	
	// New in men - Jackets in men
	@FindBy (xpath="//div[@class='categories-menu']/child::ul[2]/child::li[2]/child::a") WebElement jacketsmen;
	
	//Eco friendly
	@FindBy (xpath="//div[@id='narrow-by-list']/child::div[5]/child::div[1]") WebElement ecofriendly;
	
	 //No - Eco friendly
	@FindBy (xpath="//div[@id='layered-filter-block']/descendant::ol[3]/child::li/child::a") List<WebElement> ecofriendlyList;
	
	//SideMenu for shopping options
	@FindBy (className = "filter-options-title") List<WebElement> sideMenu;
	
	//SideMenu list 
	@FindBy (xpath = "//li[@class='item']") List<WebElement> sideMenuList;
	
	//erin recommends
	@FindBy (xpath="//div[@id='narrow-by-list']/child::div[6]/child::div[1]") WebElement erinRecommends;
	
     // No-Erin recommends
	@FindBy (xpath="//div[@id='layered-filter-block']/descendant::ol[4]/child::li/child::a") List<WebElement> noErinrecommends;
	
	//No New option
	@FindBy(xpath="//div[@id='layered-filter-block']/descendant::ol[6]/child::li/child::a") List<WebElement> noNewOption;
	
	//	View Jacket size
	@FindBy (xpath="//div[@class='column main']/descendant::li[1]/descendant::div[6]/child::div[3]") WebElement jacketsize;
	
	// Jacket Blue color
	@FindBy (xpath="//div[@class='column main']/child::div[3]/child::ol/child::li[1]/child::div/child::div/child::div[2]/child::div[2]/descendant::div[3]") WebElement bluecolor;
	
	//===============================================================================================================================
	
	//Whats new - Mens shorts
	@FindBy (xpath="//div[@class='categories-menu']/child::ul[2]/child::li[6]/child::a ") WebElement shortsmen;
	
//Shopping options- materials
	@FindBy (xpath="//div[@id='narrow-by-list']/child::div[7]/child::div[1]") WebElement materials;
	
	// Shopping options - polyster
	@FindBy (xpath="//div[@id='narrow-by-list']/child::div[7]/child::div[2]/descendant::li[7]/child::a[1]") WebElement polyester;
	
	
//Shopping options - new
	//@FindBy (xpath="//div[@id='narrow-by-list']/child::div[8]/child::div[1]") WebElement newOptions;
	
	
//No of items - 7 items
	@FindBy (xpath="//div[@class='column main']/descendant::div[2]/child::p/child::span") WebElement noOfItems;
	
	//==============================================================================================================================
	//Extra big titles - New Yoga
	@FindBy (xpath="//div[@class='column main']/descendant::a[1]/child::img") WebElement newYoga;
	
	//Pattern List name 
	@FindBy(xpath="//div[@id='layered-filter-block']/descendant::ol[13]/child::li/child::a") List<WebElement> pattern;
	
	
	
	//===============================================================================================================================
	//Performance Fabrics
	@FindBy (xpath="//div[@id='layered-filter-block']/descendant::ol[14]/child::li/child::a") List<WebElement> performance;
	
	//Dropdown =product name
	@FindBy (id="sorter") WebElement productName;
	
	//==============================================================================================================================
	//Descending order
	@FindBy (xpath="//div[@class='action sorter-action sort-asc']")   List<WebElement> descending;
	
	//=============================================================================================================================
	
	//Performanic Fabrics on Whats new page
	@FindBy (xpath="//div[@class='column main']/descendant::a[2]") WebElement performanceFabrics;
	
	
	//Helios Endurance Tank
	@FindBy (xpath="//div[@class='column main']/descendant::li[2]") WebElement heliosEnduranceTank;
	
	//Endurance tank size
	@FindBy (xpath="//div[@class='swatch-opt']/child::div[1]/child::div/child::div[2]") WebElement enduranceTankSize;
	  
	//Endurance Color 
	  @FindBy (xpath="//div[@class='swatch-opt']/child::div[2]/child::div/child::div[1]") WebElement enduranceColor;
	  
	  //Quantity of endurance tank
	  @FindBy (xpath="//input[@id='qty']") WebElement quantityTank;
	  
	  
	  
	  
	
	
	public void WhatisNew()  
	{
		whatsnew.click();
		
	}

	public void VerifyNoshoppingOptions() throws InterruptedException 
	{     
		hoodieswomen.click();
		style.click();
		fullzip.click();
		size.click();
		L_size.click();
		
		
		//Hover to Selene Yoga Hoodie
		Actions act= new Actions(driver);
		act.moveToElement(SeleneYogaHoodie_hover).build().perform();
		Thread.sleep(2000);
		
		clearAll.click();
		
	}
	
	public void ClickPants(){
		pants.click();
	}
	public void ClickClimate() {
		climate.click();
		
	}
	public void ClickWarm() {
		warm.click();
		
	}
		
	public void ClickColor() throws InterruptedException {
		color.click();
		Thread.sleep(2000);
		
	}
		
		
      public void ClickOnListView() throws InterruptedException
      {
		  //Click on List view
		list.click();
		Thread.sleep(2000);
 }
		
		
		public void ClickonBikramPant() {
		//List of elements /links
		List<WebElement> links= driver.findElements(By.tagName("a"));
		System.out.println("Total no of links: "+ links.size());
		for(int i=0;i<links.size();i++) 
		{
			WebElement currentlink= links.get(i);
			String name=currentlink.getText();
			if(name.equals("Daria Bikram Pant")) 
			{
				links.get(i).click();
				break;
			}
			
		}}
		
		public void ClickSize() throws InterruptedException {
		JavascriptExecutor js= (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,100)");
		Thread.sleep(2000);
		
		//dariaBikram_pant_size-29
		dariaBikram_pant_size.click();
		
		}
		
		public void ClickonPantColor() {
		
		dariaBikram_pant_color.click();
		}
		
		public void ClickonMoreinformation() throws InterruptedException {
			moreinformation.click();
			Thread.sleep(2000);
			
			}
		
		public void ClickonProductsDetails() {
			//Product details
			productdetails.click();
			
			}
		
		
		public void ClickonReviews() {
			//Reviews
			reviews.click(); 
			}
		
		public void ClickonRating() {
			  //Ratings
			ratings.click();
			}
		
		public void EnterName() {
			//Nickname
			nickname.sendKeys("Ronak");
			 
			}
		  
		public void EnterSummary() {
			
			summaryfield.sendKeys("This is very beautiful product. Must buy!!!!!");
			 
			}
		  
		public void EnterReviewdetails() {
			
			reviewfield.sendKeys(" I love this product. It is fab. We must look into it and one of my too go forsure ");
			
			}
		  
		public void ClickonSubmitReview() {
			
			submitreview.click();
			    	
			}
	

	public void ClickonJackets() throws InterruptedException 
	{ 
		JavascriptExecutor js= (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0, 200)");
		Thread.sleep(2000);
		
		jacketsmen.click();
	}
	
	public void ClickOnEcoFriendly() throws InterruptedException {
	//=========================================================================================================================	
		//No eco friendly
		for(int i=0; i<sideMenu.size();i++)
		{
			String menuName=sideMenu.get(i).getText();
			if(menuName.equalsIgnoreCase("Eco Collection"))
			{
				sideMenu.get(i).click();
				Thread.sleep(2000);
				for(int e=0;e<ecofriendlyList.size();e++)
				{
					String ecoListName=ecofriendlyList.get(e).getText();
					System.out.println(ecoListName);
					if(ecoListName.contains("No"))
					{
						ecofriendlyList.get(e).click();
						Thread.sleep(2000);
					}
				}
				
			}
		}
	}
		//=======================================================================================================================
		//No erin recommends
	public void ClickonErinRecommends() throws InterruptedException
	{
		for(int i=0; i<sideMenu.size();i++)
		{
			String menuName=sideMenu.get(i).getText();
			if(menuName.equalsIgnoreCase("Erin Recommends"))
			{
				sideMenu.get(i).click();
				Thread.sleep(2000);
				for(int e=0;e<noErinrecommends.size();e++)
				{
					String erinListName=noErinrecommends.get(e).getText();
					System.out.println(erinListName);
					if(erinListName.contains("No"))
					{
						noErinrecommends.get(e).click();
						Thread.sleep(2000);
					}
				}
				
			}
		}
	
		
	}
	
	
	 public void GetLinksProductGrid() 
	{
		//List of elements /links in grid mode/Jacket size and color
		List<WebElement> links= driver.findElements(By.tagName("a"));
		System.out.println("Total no of links 1: "+ links.size());
		for(int i=0;i<links.size();i++) 
		{
			WebElement currentlink= links.get(i);
			String name=currentlink.getText();
			if(name.equals("Proteus Fitness Jackshirt")) 
			{
				jacketsize.click();
				bluecolor.click();
				break;
			}
			
		}
		
		
	}
		
	
	//==========================================================================================================================


	 public void Shortsmen() throws InterruptedException 
	{
		shortsmen.click();
	}
	 public void ClickOnMaterialsdrop()
	{
		materials.click();
	}
	  public void ClickOnpolysterdrop()
	{
		polyester.click();
	}
		
		public void NewMenuClick() throws InterruptedException {
		//newOptions.click();
		//noNewOptions.click();   //Not getting selected
		
		for(int n=0; n<sideMenu.size();n++)
		{
			String menuName=sideMenu.get(n).getText();
			if(menuName.equalsIgnoreCase("New"))
			{
				sideMenu.get(n).click();
				Thread.sleep(2000);
				for(int m=0;m<noNewOption.size();m++)
				{
					String newListName=noNewOption.get(m).getText();
					System.out.println(newListName);
					if(newListName.contains("No"))
					{
						noNewOption.get(m).click();
						Thread.sleep(2000);
					}
				}
				
			}
		}

		}
		
		public void verifyNoofItems()
		{
		String valueofItems = noOfItems.getText();
		/*if (valueofItems.equals("7"))
		{
			
			System.out.println("Selected items is correct as per shopping options and Testcase is a Pass "+ "Value of item is "+ valueofItems);
			
		}
		else
		{
			System.out.println("Wrong item selected and Test case case fail  "+ "Value of item is "+valueofItems);
		}*/
		
		//Assert to check value of items
	    Assert.assertEquals(valueofItems, "7");   
	  	
	}	
	
		public void ShopNewYoga() throws InterruptedException
		{
			newYoga.click();
			Thread.sleep(2000);
		}
			
		
		public void ClickPatternMenu() throws InterruptedException {
			//Pattern -solid (23)
			for(int k=0; k<sideMenu.size();k++)
			{
				String menuName=sideMenu.get(k).getText();
				if(menuName.equalsIgnoreCase("Pattern"))
				{
					sideMenu.get(k).click();
					Thread.sleep(2000);
					for(int p=0;p<pattern.size();p++)
					{
						String patternListName=pattern.get(p).getText();
						System.out.println(patternListName);
						if(patternListName.contains("Solid"))
						{
							pattern.get(p).click();
							Thread.sleep(2000);
		
						}
					}
					
				}
			}
		}
			
		
		public void ClickPerformanceFabrics() throws InterruptedException {
			//Performance -Fabrics Yes
			for(int f=0; f<sideMenu.size();f++)
			{
				String menuName=sideMenu.get(f).getText();
				if(menuName.equalsIgnoreCase("Performance Fabric"))
				{
					sideMenu.get(f).click();
					Thread.sleep(2000);
					
					for(int g=0;g<performance.size();g++)
					{
						String perfListName=performance.get(g).getText();
						System.out.println(perfListName);
						if(perfListName.contains("Yes"))
						{
							performance.get(g).click();
							Thread.sleep(2000);
						}
					}
				}
			}
		}
		
			
		public void productDropdown()
		{
			//SortBy Dropdown - Select Product name
			Select sc = new Select(productName);
			sc.selectByVisibleText("Product Name");
			
		}
		
			
		public void FabricsPerformance() throws InterruptedException
		{
			performanceFabrics.click();
			Thread.sleep(2000);
		}
		
		public void HovertoHeliosTank() throws InterruptedException {
			Actions act= new Actions(driver);
			act.moveToElement(heliosEnduranceTank).build().perform();
			Thread.sleep(2000);
		}
		
		public void ClickOnHeliosTank() throws InterruptedException {
			heliosEnduranceTank.click();
			Thread.sleep(2000);
		}
		
		public void ClickEnduranceSize() throws InterruptedException {
			JavascriptExecutor js= (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,500)");
			Thread.sleep(2000);
		  enduranceTankSize.click();
			
			}
		
		public void ClickonBlueColor() {
			
			enduranceColor.click();
			}
		
		
		
       public void EnteronQuantity(String am)
       {
    	   quantityTank.clear();
    	   quantityTank.sendKeys(am);   //select 5
	   }
       
       
      
    	   
    	   
    	   
	
		
		
		
		
		
		
    
		
 }
 


