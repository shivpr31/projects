package project1;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.Duration;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;


public class MainClass
{  
	WebDriver driver;


	@Test
         public void mainexecution() throws InterruptedException, IOException
       {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://magento.softwaretestingboard.com/");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		
			String filepath ="F:\\Shivam 2\\Selenium Project\\Project 1.xlsx";
			FileInputStream fis = new FileInputStream(filepath);
			
			//Excel - Data Driven
			XSSFWorkbook workbook = new XSSFWorkbook (fis);
			XSSFSheet sheet = workbook.getSheet("Luna -Data");
				
				int rows = sheet.getLastRowNum();
				System.out.println("Total no of rows: "+ rows);
				
			 

						for (int r=1; r<=rows;r++) 
						{
							XSSFRow row= sheet.getRow(r);
							XSSFCell firstname=row.getCell(0);
							XSSFCell lastname =row.getCell(1);
							XSSFCell email=row.getCell(2);
							XSSFCell password =row.getCell(3);
							XSSFCell pswdconfirm =row.getCell(4);
							XSSFCell usernm =row.getCell(5);
							XSSFCell password1 =row.getCell(6);
							XSSFCell result =row.createCell(7);
							
							CreateAccount ac1= new CreateAccount(driver);
			                Login ap1 = new Login(driver);
							ResetPassword resetpwd =new ResetPassword(driver);
					
					
							
							try {
							System.out.println("First name ------>"+firstname+ 
									"           Last name------>" +lastname+           
									"           Email ------>"+email+                
							        "           Password ------>" +password+   
							        "           Confirm Password--->" +pswdconfirm+ 
							        "           Username ----> "+usernm+
							        "			Password1---->"+password1);   
							
							System.out.println("Valid data");
							result.setCellValue("Valid Data");
							
						   //Registration
											 ac1.url();
										    ac1.clickOnCreateAnAccount();
											ac1.enterfname(firstname.toString());
											ac1.enterlname(lastname.toString());
											ac1.enteremail(email.toString());
											ac1.enterpassword(password.toString());
											ac1.enterconfirmpwd(pswdconfirm.toString());
											ac1.AccCreate();
											ac1.verifyAlreadyAccountExist();
											
							//Login
											
									        ap1.Signin();
											ap1.Enterusernm(usernm.toString());
											ap1.EnterPasswordLogin(password1.toString());
                                            ap1.Loggedin();
                                            ap1.clickOnWelcomeUser();
                                            ap1.ClickSignout();
												
							//ResetPassword
											ap1.Signin();
											resetpwd.clickOnForgetPwd();
											resetpwd.enterConfirmEmail(email.toString());
											resetpwd.ClickResetPwd();	
						
						}
		                 catch(Exception e)
		                {
		                       System.out.println("Invalid data");
		                       result.setCellValue("InValid Data");
	                    }
							fis.close();
							FileOutputStream fos = new FileOutputStream (filepath);
							workbook.write(fos);
						}
       
		//Support Project
		SupportThisProject stj = new SupportThisProject(driver);
		CreateAccount ac1= new CreateAccount(driver);
		/*
		stj.ClickOnSupportProj();
		stj.Hamburgericondropdown();
		stj.Followpageicon();
		stj.FollowCloseicon();
		stj.Hamburgericondropdown();
		stj.ClickonShareicon();
		stj.ClickPageCopy();
		stj.ClickonShareClose();
		stj.Hamburgericondropdown();
		stj.ClickReportDropdown();
		ac1.url();
		stj.ClickOnSupportProj();
		
		stj.ClickCoffeeFive();
		stj.EnterNameorSocials();
		stj.Entersomething();
		stj.TickPrivatemessage();
		stj.ClickonSupport$();
		stj.ClickonCloseTestingBoard();
		
		stj.ClickLanguagetoEnglish();
		stj.ClickLanguagetoSpanish();
		stj.WebPageinSpanish();
		stj.WebPageOrginalEnglish();      
		ac1.url();   
		*/
		//Logo
		Logo logoicon= new Logo(driver);
		logoicon.VerifyLogo();
			
		
		//What's New and all tabs - creation of objects /calling driver
		WhatsNew wn =new WhatsNew(driver);
		 Women w = new Women(driver);
		 Men m = new Men(driver);
		 Gear g = new Gear (driver);
		 Training t = new  Training(driver);
		 Sale s = new Sale(driver);
		 Login ap1 = new Login(driver);
		 ShoppingCart sc = new ShoppingCart(driver);
		 SearchEntireStoreHere ss = new SearchEntireStoreHere(driver);
		 
		   
		  
		   wn.WhatisNew();
		   
		  wn.VerifyNoshoppingOptions();//Clear ALL Filter for shopping options
		 
		 wn.WhatisNew();
		 wn.ClickPants();
		 wn.ClickClimate();
		 wn.ClickWarm();
		 wn.ClickColor();
		 wn.ClickOnListView();
		 wn.ClickonBikramPant();
		 wn.ClickSize();
		 wn.ClickonPantColor();
		 wn.ClickonMoreinformation();
		 wn.ClickonProductsDetails();
		 wn.ClickonReviews();
		 wn.ClickonRating();
		 wn.EnterName();
		 wn.EnterSummary();
		 wn.EnterReviewdetails();
		 wn.ClickonSubmitReview();
		 
		 wn.WhatisNew();
		 wn.ClickonJackets();
		 wn.ClickOnEcoFriendly();
		 wn.ClickonErinRecommends();
		 wn.GetLinksProductGrid();
		 
		 
		 wn.WhatisNew();
		 wn.Shortsmen();
		 wn.ClickOnMaterialsdrop();
		 wn.ClickOnpolysterdrop();
		 wn.NewMenuClick();
		 wn.verifyNoofItems();  
		 
		  
		 wn.WhatisNew();
		 wn.ShopNewYoga();
		 wn.ClickPatternMenu();
		 wn.ClickPerformanceFabrics();   
		 wn.productDropdown();
		 
		 
		 
		 wn.WhatisNew();
		 wn.FabricsPerformance();
		 wn.HovertoHeliosTank();
		 wn.ClickOnHeliosTank();
		 wn.ClickEnduranceSize();
		 wn.ClickonBlueColor();
		 wn.EnteronQuantity("5");
		 
		 
		 //Shopping Cart
		
		
		 sc.ClickAddtoCartButton();
		 sc.ClickShowtoCartDropdown();
		 sc.CartItems();
		
		 sc.ValueofCartSubTotal();
		 //sc.DetailsSee();
		 
		 sc.ClickViewEditCart();
		 sc.EnterQuantitychange("2");
		 sc.ClickUpdateShopCart();
		 sc.ClickRemoveItems();
		 sc.EmptyCartMessage();
		 
		 
		 wn.WhatisNew();
		
		 //Women
		 w.TabWomen();
		 w.WomenTops();
		 w.TopsJackets();
		 w.ShoppingPrice();
		 w.ShoppingPriceRange();
		     //w.Sale();
		 
		 
		 w.AdrienneTrekJacket();
		 sc.AddToCompare();
		 sc.CompareList();
		 sc.RemoveCompareProduct();
		 sc.ClickOnOKitem();  //remove product from compare list
		 
		 
		  wn.WhatisNew();
		 w.TabWomen();
		 w.WomenBottom();
		w.BottomsShorts();
		w.SortByPriceDropdown();
		w.SetDescendingOrder();
		
		
		 //Mens
		ap1.Signin();
		ap1.Enterusernm("shivprcar32@gmail.com");
		ap1.EnterPasswordLogin("shivpr@123");
        ap1.Loggedin();
	    ap1.clickOnWelcomeUser();
	    
		//wn.WhatisNew();
		m.TabMen();
		m.MensTops();
		m.TopsTanks();
		m.ShowPage();    
	
		m.HoverSpartaGymTank();
		sc.AddToWishList();
		sc.AddALLtoCart();   
		m.ClickSpartaGymTank();
		
		
		sc.ClickGymTankSize();
		sc.ClickGymTankGreen();
		sc.EnterGYMTankQuantity("2");
		sc.ClickAddtoCartButton();
		
		sc.ClickShoppingCartLink();
		sc.AddCartCardioBall();  
		
		//================================================Checkout===========================================================
		
	     sc.ProceedToCheckout();
		 //sc.multipleCheckoutAddress(); //Working, but not needed for now
		
	
		//============================================Shipping==============================================================
	    
	    /*  (DEFAULT ADDRESS AND SHIPPING ADDRESS)----->>> ALREADY UPDATED BY AUTOMATION SCRIPT ===>> ADDRESS SAVED IN ADDRESS BOOK
	     
	    sc.StreetAddress("XYZ Street");
	    sc.CityName("New York City");
	    sc.StateName();
	    sc.PostCode("10001");
	    sc.EnterTelephone("9022716187");
	    sc.ShippingMethodBTN();          //shipping method:Best Way
	    sc.SubmitBTN();
	    
	    sc.ClickonBillingsameShipping();
	    sc.ClickPlaceOrderBTN();
	    
	    sc.CLickonContinueShopBTN();
	    //(DEFAULT ADDRESS AND SHIPPING ADDRESS)----->> ALREADY UPDATED BY AUTOMATION SCRIPT.So can not  run, hence commented
	    */
	    
	   /*
	    * 
	    * Note message: Order has been placed and  an Order no: 000006430 has been generated. 
	    * This all information along with tracking details  will be shared on the email.
	    * 
	    *
	    */
	    
		 
		 
	   //New Address button
	    	sc.ClickonNewAddressBTN();
	    	sc.StreetAddress("Dream City World wide");
		    sc.CityName("New Jersey");
		    sc.StateName();
		    sc.PostCode("10094");
		    sc.EnterTelephone("9022716100");
		    sc.ClickShipHereBTN();   // Ship here 
		    
		    sc.ShippingMethodBTN();          //shipping method:Best Way
		    sc.SubmitBTN();
		    sc.ClickonBillingsameShipping();
		    sc.ClickPlaceOrderBTN();
		    
		    sc.CLickonContinueShopBTN();
		    
		    
		
		 //Gears
		 g.Gears();
		
		 //Trainings
		 t.Trainings();
		 
		 //Sale - Validate various options for product 
		 s.sale();
		 s.ClickTeesWomen();
		 s.sale();
		 s.ClickHoodiesSweatShirts();
		 s.sale();
		 s.ClickGearBags();
		 s.sale();
		 s.ClickWomenDeals();
		 s.sale();
		 s.ClickMenDeals();
		 s.sale();
		 s.ClickGearLuma();
		 s.sale();
		 s.ClickSaleTees();
		 s.sale();
		 
		 
		//Entire Store search
		 ss.EnterSearch("pants");
		 ss.AutoSearchList();
		 
		 
		 ss.AdvancedSearch();
		 ss. EnterProductSKU("WJ06");
		 ss.ClickSearchBtn();
		 ss.SearchitemFound(); 
		 driver.close();
		 
	
		 
    }
}
						