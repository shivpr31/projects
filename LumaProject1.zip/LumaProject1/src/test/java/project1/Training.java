package project1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Training {
	WebDriver driver;
	
	public Training(WebDriver idriver) 
	{
		driver=idriver;
		PageFactory.initElements(driver, this);
		
	}

  @FindBy (xpath="//ul[@id='ui-id-2']/child::li[5]/descendant::span[2]") WebElement train;
  @FindBy (xpath="//ul[@id='ui-id-2']/child::li[5]/child::ul/descendant::a") WebElement videodownload;

	
	public void Trainings() throws InterruptedException {
		Actions act= new Actions(driver);
		//hover on training
		act.moveToElement(train).build().perform();
		Thread.sleep(2000);
		
		//video download
		videodownload.click();
		
		
		
	}

}
