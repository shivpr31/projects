package project1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Login

{
	
	WebDriver driver;
	
		public Login(WebDriver idriver)
	{
		driver=idriver;
		//Page Factory =class
		PageFactory.initElements(driver, this);
	}
		
		//Sign in >> Login
		@FindBy (xpath="//div[@class='panel wrapper']/descendant::ul/child::li[2]/child::a[1]") WebElement signin;
		@FindBy (name="login[username]") WebElement username;
		@FindBy (name="login[password]") WebElement passwordLogin;
		@FindBy (name="send") WebElement loggedin;
		
		@FindBy (xpath="//div[@class='page messages']/child::div[2]/descendant::div[3]") WebElement incorrectLoginMessage;
	
		
		//profile
		@FindBy (xpath = "//div[@class='panel header']/child::ul[1]/child::li[2]/descendant::button[1]") WebElement welcmArrow;    //div[@class='panel wrapper']/child::div/child::ul[1]/descendant::button[1]
	
		//SignOut
		@FindBy (xpath="//div[@class='page-wrapper']/descendant::ul[2]/child::li[3]/child::a[1]") WebElement signout;
		
		
		
		//Sign in
        
        public void Signin () throws InterruptedException
		{
        	 signin.click();
        	 Thread.sleep(2000);
		}
        
        public void Enterusernm(String un)
		{
        	username.sendKeys(un);	
		}
		
		
        public void EnterPasswordLogin(String pl) 
        {
        	passwordLogin.sendKeys(pl);
	    }
        
        
        public void Loggedin ()
		{
        	loggedin.click();	
		}
        
        
        public void verifyIncorrectLogin()  //Message if incorrect Login
        {
        	try 
        {
        	if(incorrectLoginMessage.isDisplayed()) 
        	{
        		System.out.println(" User is requested to enter valid Login credentials, Test Case is a Pass");
        	}
        	
        	else 
        	{
        		System.out.println("User must Sign-on first and then enter valid Sign-in details, Test Case is a Fail");
        	}
        }   
        	catch(Exception e) 
        {
        	String incorrectmessage= incorrectLoginMessage.getText();
        	System.out.println("The incorrect Login message is  " +incorrectmessage);
        	
        }
        	}
    	
       
   
        //--------------------------------------------------------------------------------------------------
        //Signout
        public void clickOnWelcomeUser() throws InterruptedException
        {
        	welcmArrow.click();
        	Thread.sleep(2000);
        }
        public void  ClickSignout ()
		{
        	 signout.click();	
		}
        
        
        
       
        
        
	

}
