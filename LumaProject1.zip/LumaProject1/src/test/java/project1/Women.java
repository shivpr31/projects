package project1;

import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class Women {
	
WebDriver driver;
	
	public Women(WebDriver idriver) 
	{
		driver=idriver;
		PageFactory.initElements(driver, this);
		
	}

	
	//women element
	@FindBy (xpath="//nav[@class='navigation']/descendant::li[2]/descendant::a[1]") WebElement women;
	
	//women tops / jacket
	@FindBy (xpath="//nav[@class='navigation']/child::ul/child::li[2]/child::ul/descendant::a[1]") WebElement topswomen;
	@FindBy (xpath="//nav[@class='navigation']/child::ul/child::li[2]/child::ul/descendant::ul[1]/descendant::a[1]") WebElement jacketswomen;
	
	//Price - shopping options
	@FindBy (xpath="//div[@id='narrow-by-list']/child::div[11]/child::div[1]") WebElement price;
	//PriceRange
	@FindBy (xpath="//div[@id='narrow-by-list']/child::div[11]/child::div[2]/child::ol/child::li[2]/child::a") WebElement priceRange;
	
	//SideMenu for shopping options
		@FindBy (className = "filter-options-title") List<WebElement> sideMenu;
		
		//Yes-sale 
		@FindBy (xpath="//div[@id='narrow-by-list']/child::div[12]/child::div[2]/child::ol/child::li/child::a") List<WebElement>  yesSale;
	
	//Adrienne Trek Jacket
	@FindBy (xpath="//div[@class='column main']/child::div[3]/child::ol/child::li[1]/descendant::a[1]") WebElement adriennetrekjacket;
	
		
	//women bottom /shorts
	@FindBy(xpath="//nav[@class='navigation']/descendant::li[8]/child::a[1]") WebElement bottomWomen;
	@FindBy (xpath="//nav[@class='navigation']/descendant::li[10]/child::a[1]") WebElement shortsWomen;

	//Set Descending order
	@FindBy (xpath="//div[@class='column main']/child::div[2]/child::div[3]/child::a") WebElement descendingorder;
	
	//Dropdown =price
	@FindBy (id="sorter") WebElement sortPrice;
		
	
	
	
	public void TabWomen() throws InterruptedException
	{
		Actions act= new Actions(driver);
		act.moveToElement(women).build().perform();
		Thread.sleep(2000);	
	}
	
	public void WomenTops() {
		Actions act= new Actions(driver);
		act.moveToElement(topswomen).build().perform();
		
	}
	
	public void TopsJackets() throws InterruptedException {
		Actions act= new Actions(driver);
		act.moveToElement(jacketswomen).build().perform();
		jacketswomen.click();
		Thread.sleep(2000);
	}
    
	public void ShoppingPrice() {
		price.click();
	}
	
	public void ShoppingPriceRange() {
		priceRange.click();
	}
	
	/*public void Sale() throws InterruptedException 
	{
		
		for(int s=0; s<sideMenu.size();s++)
		{
			String menuName=sideMenu.get(s).getText();
			if(menuName.equalsIgnoreCase("Sale"))
			{
				sideMenu.get(s).click();
				Thread.sleep(2000);
				for(int o=0;o<yesSale.size();o++)
				
				{
					String saleListName= yesSale.get(o).getText();
					System.out.println(saleListName);
					if(saleListName.contains("Yes"))
					{
						 yesSale.get(o).click();
						Thread.sleep(2000);
					}
				}
				
			}
		}	
		
	}*/
	
	
	public void AdrienneTrekJacket() throws InterruptedException {
		Actions act= new Actions(driver);
		act.moveToElement(adriennetrekjacket).build().perform();
		Thread.sleep(2000);
		adriennetrekjacket.click();
		
	} 
	
	public void WomenBottom() {
		Actions act= new Actions(driver);
		act.moveToElement(bottomWomen).build().perform();
		
	}
	
    public void BottomsShorts() throws InterruptedException {
		Actions act= new Actions(driver);
		act.moveToElement(shortsWomen).build().perform();
		shortsWomen.click();
		Thread.sleep(2000);
	}
    
    public void SortByPriceDropdown()
	{
		
		Select sc = new Select(sortPrice);
		sc.selectByVisibleText("Price");
		
	}
    public void SetDescendingOrder() throws InterruptedException {
    	descendingorder.click();
    	
    	JavascriptExecutor js= (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,3500)");
		Thread.sleep(2000);
		
		js.executeScript("window.scrollBy(0,-3500)");
		
    }
	
	
	
	
	
	
	
	
	
}
