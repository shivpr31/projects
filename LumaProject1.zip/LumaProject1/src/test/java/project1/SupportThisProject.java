package project1; 

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SupportThisProject {
	WebDriver driver;
	
	public SupportThisProject(WebDriver idriver) {
		driver=idriver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy (xpath="//div[@class='panel wrapper']/child::div/child::ul/descendant::a[1]")  WebElement suportproj;
	
	@FindBy (xpath="//div[@id='app']/child::div/child::div[1]/descendant::div[9]") WebElement hamburgericon;
	@FindBy (xpath="//div[@class=\"text-dark text-sm font-cr-book leading-5\"]")  WebElement followIcon;
	@FindBy (xpath="//div[@id='app']/descendant::div[28] ") WebElement closeFollow;
	@FindBy (xpath="//div[@id='app']/descendant::div[13]/child::ul/child::li[2]/child::div[1]/child::div[2]") WebElement shareIcon;
	@FindBy (xpath="//div[@class='mt-4 flex']/child::button/child::span[1]") WebElement copyPage;
	@FindBy (xpath="//div[@id='app']/descendant::div[28]") WebElement closeShareWindow;
	@FindBy (xpath="//div[@id='app']/descendant::div[13]/child::ul/child::li[3]/descendant::div[2]") WebElement reportuser;

	//@FindBy (xpath= "") WebElement loginToBuyCoffee;   //div [@id='app']/descendant::div[8]/descendant::div[13]  ???
	
	
	@FindBy (xpath="//input[@value='5']") WebElement fiveCoffee;
	@FindBy (xpath="//input[@type='text']") WebElement nameOrsocial;
	@FindBy (xpath="//div[@class='relative group mt-4 xs:mt-4 text-sm']/child::textarea[1]") WebElement saySomething;
	@FindBy (xpath="//div[@class='emoji-picker-toggle text-18 cursor-pointer group/emojiIcon']")  WebElement smileyPeople;
	@FindBy (xpath="//label[@class='inline-flex cursor-pointer items-center relative']//child::span[2]") WebElement privateMessage;
	@FindBy (xpath="//div[@class='relative group']/child::button/child::span[1] ") WebElement support$;
	@FindBy (xpath="//div[@class='fixed inset-0 z-10 w-screen overflow-y-auto']/descendant::div[5]") WebElement closeSWTestingBoard;
	
	@FindBy (xpath="//span[@class='text-dark font-cr-regular block']")  WebElement englishLanguage;
	@FindBy (xpath="//ul[@class='w-full block p-3 font-cr-regular']/child::li[3]") WebElement spanish;
	
	@FindBy (xpath="//span[@class='text-dark font-cr-regular block']") WebElement spanishwebpage;
	@FindBy (xpath="//ul[@class='w-full block p-3 font-cr-regular']/child::li[1]") WebElement englishFinal;
	
  //Support Project click

	 public void ClickOnSupportProj() throws InterruptedException
	 {
		 suportproj.click();
		
		 
		 
	 }
     public void Hamburgericondropdown()
     {
    	 hamburgericon.click();
    	
     }
     public void Followpageicon() 
      {
    	 followIcon.click();	 
     }
     public void FollowCloseicon() throws InterruptedException 
     {
    	 closeFollow.click();
    	 Thread.sleep(2000);
     }
     public void ClickonShareicon()
     {
    	 shareIcon.click();
     }
     public void ClickPageCopy()
     { copyPage.click();
    	 
     }
     public void ClickonShareClose()
 {
    	 closeShareWindow.click();
     }
     public void ClickReportDropdown() throws InterruptedException
     {
    	 reportuser.click();
    	 Thread.sleep(2000);
     }
     public void ClickCoffeeFive() 

     {
    	 fiveCoffee.click();
     }
     public void EnterNameorSocials() 
     {
    	 nameOrsocial.sendKeys("shivpr");
     }
     public void Entersomething() 
     {
    	 saySomething.sendKeys("Thank you, You are beautiful. Take care!");
     }
     public void AddSmileytoSomething() 
{
    	 smileyPeople.click();
     }
     public void TickPrivatemessage()
 {
    	 privateMessage.click();
     }
     public void ClickonSupport$()
     {
    	 support$.click();
     }
     public void ClickonCloseTestingBoard()
     {
    	 closeSWTestingBoard.click();
     }
     public void ClickLanguagetoEnglish() {
    	 englishLanguage.click();
     }
     public void ClickLanguagetoSpanish() throws InterruptedException {
    	 spanish.click();
    	 Thread.sleep(5000);
     }
     public void WebPageinSpanish()
     {
    	 spanishwebpage.click();
     }
     public void WebPageOrginalEnglish() throws InterruptedException
     {
    	 englishFinal.click();
    	 Thread.sleep(2000);
     }
     
     
     
}


