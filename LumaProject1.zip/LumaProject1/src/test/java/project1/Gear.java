package project1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

	public class Gear {
		WebDriver driver;
		public Gear(WebDriver idriver) 
		{
			driver=idriver;
			PageFactory.initElements(driver, this);
			
		}
	
		//gear element
		@FindBy (xpath="//ul[@id='ui-id-2']/child::li[4]/descendant::span[2]") WebElement gearTab;
		
		//Fitness equipment
		@FindBy (xpath="//nav[@class='navigation']/descendant::li[22]/child::a[1]") WebElement fitequipment;
		
		
		public void Gears() throws InterruptedException {
			Actions act= new Actions(driver);
			act.moveToElement(gearTab).build().perform();
			Thread.sleep(2000);
			
		}

	
	
	
	
	

}
