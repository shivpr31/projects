package project1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Logo 
{
	
	WebDriver driver;
	
	public Logo (WebDriver idriver) 
	{
		driver=idriver;
		PageFactory.initElements(driver, this);
	}
	
	//Logo
	@FindBy (xpath="//a[@class='logo']") WebElement logo;
	
	
	public void VerifyLogo() throws InterruptedException 
	{
	if(logo.isDisplayed())
	{
		String ActualTitle= driver.getTitle();
		String ExpectedTitle = "Home Page";
		
		if(ActualTitle.equals(ExpectedTitle))
		{    logo.click();
			Thread.sleep(3000);
			String CurrentURL= driver.getCurrentUrl();
			System.out.println("HomePageTitle is verified and Test case is a Pass");
			System.out.println("URL of Homepage:  "+CurrentURL);
		}   else
		{
			System.out.println("HomePageTitle is  not verified and Test case is a Fail");
		}
		
		
	}
		
	}

		
	}