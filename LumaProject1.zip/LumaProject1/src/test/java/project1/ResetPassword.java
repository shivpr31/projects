package project1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ResetPassword {
	
	WebDriver driver;
	
	public ResetPassword(WebDriver idriver)
{
	driver=idriver;
	//Page Factory =class
	PageFactory.initElements(driver, this);
}
	
	//Forget Password >>  Reset Password - Only Success Email, but no email received
			@FindBy (xpath="//a[@class='action remind']") WebElement forgetPwd;
			@FindBy (xpath="//input[@name='email']") WebElement confirmEmail;
			@FindBy (xpath="//button[@class='action submit primary']") WebElement resetPwd;
			
			
			public void clickOnForgetPwd() 
	        {
	        	forgetPwd.click();
		    }
	        
	        public void enterConfirmEmail(String ce) 
	        {
	        	confirmEmail.sendKeys(ce);
		    }
	        public void ClickResetPwd() 
	        {
	        	resetPwd.click();
		    }

}
