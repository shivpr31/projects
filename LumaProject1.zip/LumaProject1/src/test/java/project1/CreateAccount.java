package project1;


import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CreateAccount {
	WebDriver driver;
	
	public CreateAccount(WebDriver idriver)
{
	driver=idriver;
	PageFactory.initElements(driver, this);
}
	
	@FindBy (linkText = "Create an Account") WebElement createanAcc;
	@FindBy (name="firstname") WebElement firstname;
	@FindBy (name="lastname") WebElement lastname;
	@FindBy (name="email") WebElement email;
	@FindBy (name="password") WebElement password;
	@FindBy (name="password_confirmation") WebElement pswdconfirm;
	@FindBy (xpath = "//div[@class='primary']/child::button") WebElement AccCreated;
	@FindBy (xpath="//div[@class='page messages']/child::div[2]/descendant::div[2]") WebElement AlreadyAccexists;
	
	
	//---------------------------------------------------------------------------------------------------------------
	 public void url() throws InterruptedException 
		{
			driver.get("https://magento.softwaretestingboard.com/");
			Thread.sleep(2000);
		}
	 
	 
	 public void clickOnCreateAnAccount() throws IOException
	{
		 createanAcc.click();
    	
	}  
   
	public void enterfname(String fm)
	{
		firstname.sendKeys(fm);	
	}
	
	
    public void enterlname(String lm) 
    {
    	lastname.sendKeys(lm);
    }
    
    public void enteremail (String em)
    {
    	email.sendKeys(em);
	}
	  
    public void enterpassword (String pwd) {
    	password.sendKeys(pwd);	
	}
	
    public void enterconfirmpwd (String cpwd)
    {
    	pswdconfirm.sendKeys(cpwd);
		
	}
    
    public void AccCreate ()
	{
    	AccCreated.click();	
	}
	
    public void verifyAlreadyAccountExist()  //Message if already created account
    {try {
    	if(AlreadyAccexists.isDisplayed()) {
    		System.out.println("Account Already Exist, Test Case is a Pass");
    	}
    	
    	else {
    		System.out.println("Perform Sign-in or Use Forget Password to retrive your Password, Test Case is a Fail");
    	}
    }catch(Exception e) {
    	String message= AlreadyAccexists.getText();
    	System.out.println("The Already existed Account message is  " +message);
    	
    }
	

}}
	                    

