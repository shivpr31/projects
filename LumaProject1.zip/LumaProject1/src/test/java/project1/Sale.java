package project1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Sale {
	WebDriver driver;
	public Sale(WebDriver idriver) 
	{
		driver=idriver;
		PageFactory.initElements(driver, this);
		
	}
	//Sale
		@FindBy (xpath="//ul[@id='ui-id-2']/child::li[6]/descendant::span") WebElement sell;
		
		//Womens deal- Tees
		@FindBy (xpath="//div[@class='categories-menu']/child::ul[1]/child::li[3]") WebElement teeswomen;
		
		//Mens deal - Hoodies and sweat shirts
		@FindBy (xpath="//div[@class='categories-menu']/descendant::li[7]/child::a") WebElement hoodiesSweatshirt;
		
		//Gear deals - Bags
		@FindBy (xpath="//div[@class='categories-menu']/descendant::li[12]/child::a") WebElement bagsGear;
		//---------------------
		
		//Shop womens deal
		@FindBy (xpath= "//div[@class='columns']/descendant::a[1]") WebElement dealsWomen;
		
		//Shop mens deal
		@FindBy (xpath= "//div[@class='columns']/descendant::a[2]") WebElement dealsmen;
		
		
		//Shop Luma Gear
		@FindBy (xpath="//div[@class='column main']/child::div[1]/child::div/child::div[1]/child::a[2]/descendant::span[3]") WebElement lumaGear;
		
		//Tees on sale
		@FindBy (xpath= "//div[@class='column main']/child::div[1]/child::div/child::div[2]/child::a[3]/child::span[1]/descendant::span[2]") WebElement teesonSale;
		
		
		
		
		
		public void sale() {
			sell.click();
			
		}
	  
		public void ClickTeesWomen() {
			teeswomen.click();
			
		}
		public void ClickHoodiesSweatShirts() {
			hoodiesSweatshirt.click();
			
		}public void ClickGearBags() {
			bagsGear.click();
			
		}public void ClickWomenDeals() {
			dealsWomen.click();
			
		}
		public void ClickMenDeals() {
			dealsmen.click();
			
		}
		public void ClickGearLuma() {
			lumaGear.click();
			
		}
		public void ClickSaleTees() {
			teesonSale.click();
			
		}
}
